﻿
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.EntityFrameworkCore;
using RPG_Sheet_characters_admin.Models;
public class ApplicationDbContext 
{

    public class DbValues()
    {
        public readonly string connection = "\"Server=mysql-scaredb-scare-database.g.aivencloud.com;Port=13179;Database=scare;User=sistema_scare;Password=AVNS_vSZaJ9VZV3aX8gVZhu8;SslMode=Required;\"";
    }    

}
